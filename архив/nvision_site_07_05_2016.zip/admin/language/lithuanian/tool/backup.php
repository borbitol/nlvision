<?php
// Heading
$_['heading_title']    = 'Kopijuoti/Atstatyti';

// Text
$_['text_backup']      = 'Parsiųsti atsarginę kopiją';
$_['text_success']     = 'Jūs sėkmingai įkėlėte savo DB!';

// Entry
$_['entry_restore']    = 'Atstatyti iš atsarginės kopijos:';
$_['entry_backup']     = 'Atstatyti:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti atsarginių kopijų!';
$_['error_backup']     = 'Privalote pasirinkti bent vieną lentelę!';
$_['error_empty']      = 'Įkelta rinkmena tuščia!';
?>