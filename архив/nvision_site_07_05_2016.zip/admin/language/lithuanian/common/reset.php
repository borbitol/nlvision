<?php
//
// developer.lt
//

// header
$_['heading_title']  = 'Slaptažodžio keitimas';

// Text
$_['text_reset']     = 'Pakeiskite savo slaptažodį!';
$_['text_password']  = 'Įveskite naują pageidaujamą slaptažodį.';
$_['text_success']   = 'Slaptažodis sėkmingai pakeistas.';

// Entry
$_['entry_password'] = 'Slaptažodis:';
$_['entry_confirm']  = 'Pakartokite slaptažodį:';

// Error
$_['error_password'] = 'Slaptažodžio ilgis turi būti nuo 5 iki 20 simbolių!';
$_['error_confirm']  = 'Slaptažodis ir pakartotas slaptažodis nesutapo!';
?>