<?php
//
// developer.lt
//

// header
$_['heading_title']  = 'Administravimas';

// Text
$_['text_heading']   = 'Administravimas';
$_['text_login']     = 'Įveskite prisijungimo duomenis.';
$_['text_forgotten'] = 'Slaptažodžio priminimas';

// Entry
$_['entry_username'] = 'Vartotojo vardas:';
$_['entry_password'] = 'Slaptažodis:';

// Button
$_['button_login']   = 'Prisijungti';

// Error
$_['error_login']    = 'Neteisingas vartotojo vardas arba slaptažodis.';
$_['error_token']    = 'Neteisinga sesijos žyma. Prisijunkite iš naujo.';
?>
