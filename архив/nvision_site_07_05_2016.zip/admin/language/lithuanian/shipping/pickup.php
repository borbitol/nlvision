<?php
// Heading
$_['heading_title']    = 'Atsiimti patiems';

// Text 
$_['text_shipping']    = 'Pristatymas';
$_['text_success']     = 'Jūs sėkmingai modifikavote atsiėmimo patiems nustatymus!';

// Entry
$_['entry_geo_zone']   = 'Geo zona:';
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rūšiavimo eiliškumas:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti atsiėmimo patiems nustatymus!';
?>