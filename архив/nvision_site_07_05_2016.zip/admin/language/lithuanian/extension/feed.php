<?php
// Heading
$_['heading_title']  	= 'Prekių RSS kanalai';

// Text
$_['text_install']   	= 'Įdiegti';
$_['text_uninstall'] 	= 'Pašalinti';

// Column
$_['column_name']    	= 'Prekių RSS pavadinimas';
$_['column_status']  	= 'Būsena';
$_['column_action']  	= 'Veiksmas';

// Error
$_['error_permission']  = 'Neturite teisių redaguoti RSS nustatymų!';
?>