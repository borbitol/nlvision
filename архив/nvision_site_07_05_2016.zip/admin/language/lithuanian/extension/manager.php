<?php

//
// developer.lt
//

// Heading 
$_['heading_title']    = 'Praplėtimai';

// Text
$_['text_success']     = 'Sėkmingai išsaugoti praplėtimų pakeitimai!';

// Error
$_['error_permission'] = 'Neturite teisių modifikuoti praplėtimus!';
$_['error_upload']     = 'Privalote įkelti rinkmeną!';
$_['error_filetype']   = 'Netinkamas rinkmenos tipas!';
?>