<?php
// Heading
$_['heading_title']     = 'Pristatymas';

// Text
$_['text_install']      = 'Įdiegti';
$_['text_uninstall']    = 'Pašalinti';

// Column
$_['column_name']       = 'Pristatymo būdas';
$_['column_status']     = 'Būsena';
$_['column_sort_order'] = 'Rūšiavimo eiliškumas';
$_['column_action']     = 'Veiksmas';

// Error
$_['error_permission']  = 'Jūs neturite teisės modifikuoti pristatymą!';
?>