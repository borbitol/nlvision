<?php
// Heading
$_['heading_title']     = 'Moduliai';

// Text
$_['text_install']      = 'Įdiegti';
$_['text_uninstall']    = 'Pašalinti';
$_['text_left']         = 'Kairėje';
$_['text_right']        = 'Dešinėje';

// Column
$_['column_name']       = 'Modulio pavadinimas';
$_['column_position']   = 'Pozicija';
$_['column_status']     = 'Būsena';
$_['column_sort_order'] = 'Rūšiavimo tvarka';
$_['column_action']     = 'Veiksmas';

// Error
$_['error_permission']  = 'Jūs neturite teisės modifikuoti modulius!';
?>