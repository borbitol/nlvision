<?php
// Heading
$_['heading_title']     = 'Užsakymų suma';

// Text
$_['text_install']      = 'Įdiegti';
$_['text_uninstall']    = 'Pašalinti';

// Column
$_['column_name']       = 'Užsakymų suma';
$_['column_status']     = 'Būsena';
$_['column_sort_order'] = 'Rūšiavimo eiliškumas';
$_['column_action']     = 'Veiksmas';

// Error
$_['error_permission']  = 'Jūs neturite teisės modifikuoti sumas!';
?>