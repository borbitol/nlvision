<?php
//
// developer.lt
//

// Heading
$_['heading_title'] = 'Draudžiamas veiksmas!'; 

// Text
$_['text_permission'] = 'Jūs neturite teisės peržiūrėti šį puslapį, prašome kreiptis į administratorių.';
?>
