<?php
//
// developer.lt
//

// Heading
$_['heading_title'] = 'Puslapis nerastas!';

// Text
$_['text_not_found'] = 'Ieškomas puslapis nerastas. Maloniai prašome susisiekti su parduotuvės administracija per kontaktų formą';
?>
