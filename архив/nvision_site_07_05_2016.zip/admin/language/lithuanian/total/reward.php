<?php
// Heading
$_['heading_title']    = 'Lojalumo taškai';

// Text
$_['text_total']       = 'Užsakymo suma';
$_['text_success']     = 'Sėkmingai atnaujinote lojalumo taškų nustatymus!';

// Entry
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rikiavimas:';

// Error
$_['error_permission'] = 'Neturite teisių redaguoti lojalumo taškų duomenų!';
?>