<?php
// Heading
$_['heading_title']    = 'Kuponai';

// Text
$_['text_total']       = 'Užsakymo suma';
$_['text_success']     = 'Jūs sėkmingai modifikavote kupono užsakymo sumą!';

// Entry
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rūšiavimo eiliškumas:';

// Error
$_['error_permission'] = 'Jūs neturite teisės modifikuotu kupono užsakymo sumą!';
?>