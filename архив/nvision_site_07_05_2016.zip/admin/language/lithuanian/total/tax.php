<?php
// Heading
$_['heading_title']    = 'Mokesčiai';

// Text
$_['text_total']       = 'Užsakymo suma';
$_['text_success']     = 'Jūs sėkmingai modifikavote bendrus mokesčius!';

// Entry
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rūšiavimo eiliškumas:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti bendrus mokesčius!';
?>