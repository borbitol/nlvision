<?php
// Heading
$_['heading_title']    = 'Tarpinė suma';

// Text
$_['text_total']       = 'Užsakymo suma';
$_['text_success']     = 'Jūs sėkmingai modifikavote tarpinę sumą!';

// Entry
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rūšiavimo eiliškumas:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti tarpinę sumą!';
?>