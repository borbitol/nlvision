<?php
// Heading
$_['heading_title']      = 'Nemokamas atsiskaitymas';

// Text
$_['text_payment']       = 'Mokėjimai';
$_['text_success']       = 'Sėkmingai atnaujinote nemokamo atsiskaitymo modulio duomenis!';

// Entry
$_['entry_order_status'] = 'Užsakymo būsena:';
$_['entry_status']       = 'Būsena:';
$_['entry_sort_order']   = 'Rikiavimas:';

// Error
$_['error_permission']   = 'Neturite teisių redaguoti nemokamo atsiskaitymo modulio!';
?>