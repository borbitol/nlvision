<?php
// Text
$_['text_subject']  = '%s - slaptažodžio atstatymo užklausa';
$_['text_greeting'] = 'Buvo užklaustas naujas slaptažodis %s administravimui.';
$_['text_change']   = 'Kad atstatytumėte savo slaptažodį, paspauskite žemiau esančią nuorodą:';
$_['text_ip']       = 'Užklausa buvo gauta iš šio IP adreso: %s';
?>