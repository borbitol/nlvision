<?php
// Text
$_['text_subject']  = 'Jūs išsiuntėte dovanų čekį iš %s';
$_['text_greeting'] = 'Sveikiname, Jūs gavote dovanų čekį, kurio vertė %s';
$_['text_from']     = '%s atsiuntė Jums šį dovanų čekį.';
$_['text_message']  = 'Prie čekio nurodytas komentaras: ';
$_['text_redeem']   = 'Tam, kad galėtumėte panaudoti šį čekį, Jums reikia užsirašyti jo kodą, kuris yra <b>%s</b>, ir paspausti žemiau esančią nuorodą. Parduotuvėje išsirinkite Jums patinkančias prekes, kurių pirkimui norėtumėte panaudoti šį dovanų čekį. Įveskite dovanų čekio kodą į tam tikslui skirtą lauką pirkinių krepšelio puslapyje prieš pradedant apmokėjimo procesą.';
$_['text_footer']   = 'Galite atsakyti į šį laišką, jei turite kokių nors klausimų ar neaiškumų.';
?>