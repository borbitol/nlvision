<?php
// Text
$_['text_subject']       = '%s - grąžinimo atnaujinimas %s';
$_['text_return_id']     = 'Gražinimo ID:';
$_['text_date_added']    = 'Grąžinimo data:';
$_['text_return_status'] = 'Grąžinimo būsena pasikeitė į:';
$_['text_comment']       = 'Grąžinimo komentarai:';
$_['text_footer']        = 'Galite atsakyti į šį laišką, jei turite kokių nors klausimų ar neaiškumų.';
?>