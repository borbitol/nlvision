<?php
// Text
$_['text_approve_subject']      = '%s - Jūsų partnerystės paskyra buvo aktyvuota!';
$_['text_approve_welcome']      = 'Sveiki ir ačiū, kad užsiregistravote %s!';
$_['text_approve_login']        = 'Jūsų paskyra sukurta ir dabar galite prisijungti, naudodamiesi savo el. pašto adresu ir slaptažodžiu. Tai galima padaryti prisijungus prie mūsų puslapio arba šiuo adresu:';
$_['text_approve_services']     = 'Po prisijungimo galėsite sugeneruoti partnerystės kodus, stebėti gaunamus komisinius mokesčius ir keisti savo paskyros informaciją.';
$_['text_approve_thanks']       = 'Ačiū,';
$_['text_transaction_subject']  = '%s - partnerystės komisinis mokestis';
$_['text_transaction_received'] = 'Jūsų gautas komisinis mokestis: %s!';
$_['text_transaction_total']    = 'Jūsų visų komisinių mokesčių suma: %s.';
?>