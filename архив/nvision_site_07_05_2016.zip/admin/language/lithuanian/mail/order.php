<?php
// Text
$_['text_subject']      = '%s - Užsakymo informacija %s';
$_['text_order']        = 'Užsakymo ID:';
$_['text_date_added']   = 'Užsakymo data:';
$_['text_order_status'] = 'Jūsų užsakymo būsena:';
$_['text_comment']      = 'Komentarai:';
$_['text_invoice']      = 'Jeigu esate sukūrę paskyrą su vartotojo vardu ir slaptažodžiu, norėdami peržiūrėti savo užsakymą, paspauskite žemiau esančią nuorodą:';
$_['text_footer']       = 'Atsakykite į šį laišką, jei turite papildomų klausimų.';
$_['text_link']         = 'Norėdami peržiūrėti savo užsakymą, paspauskite žemiau esančią nuorodą:';
?>