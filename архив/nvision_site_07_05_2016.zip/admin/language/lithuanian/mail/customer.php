<?php
// Text
$_['text_approve_subject']  = '%s - Jūsų paskyra aktyvuota!';
$_['text_approve_welcome']  = 'Ačiū, kad prisiregistravote el. parduotuvėje %s!';
$_['text_approve_login']    = 'Jūsų paskyra sukurta ir Jūs galite prisijungti su savo el. pašto adresu ir slaptažodžiu šiuo adresu:';
$_['text_approve_services'] = 'Užsiregistravę galėsite peržiūrėti savo užsakymus, spausdinti sąskaitas faktūras, redaguoti savo vartotojo paskyros informaciją.';
$_['text_approve_thanks']   = 'Ačiū,';

$_['text_transaction_subject']  = '%s - Paskyros kreditas';
$_['text_transaction_received'] = 'Jūs gavote paskyros kreditą: %s!';
$_['text_transaction_total']    = 'Viso turima kredito: %s.' . "\n\n" . 'Jūsų kreditas bus automatiškai panaudotas kito užsakymo metu.';
$_['text_reward_subject']       = '%s - Lojalumo taškai';
$_['text_reward_received']      = 'Jūs gavote lojalumo taškų: %s!';
$_['text_reward_total']         = 'Šiuo metu turima lojalumo taškų: %s.';
?>