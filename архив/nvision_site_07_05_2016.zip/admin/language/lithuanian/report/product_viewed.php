<?php
// Heading
$_['heading_title']  = 'Prekių peržiūrų ataskaita';

// Text
$_['text_success']   = 'Sėkmingai anuliavote prekių peržiūrų ataskaitą!';

// Column
$_['column_name']    = 'Prekė';
$_['column_model']   = 'Modelis';
$_['column_viewed']  = 'Peržiūrėta';
$_['column_percent'] = 'Procentas';
?>