<?php
// Heading
$_['heading_title']    = 'Kuponų ataskaita';

// Column
$_['column_name']      = 'Kuponas';
$_['column_code']      = 'Kodas';
$_['column_orders']    = 'Užsakymai, vnt';
$_['column_total']     = 'Viso';
$_['column_action']    = 'Veiksmai';

// Entry
$_['entry_date_start'] = 'Pradžia:';
$_['entry_date_end']   = 'Pabaiga:';
?>