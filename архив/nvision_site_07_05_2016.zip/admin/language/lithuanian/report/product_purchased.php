<?php
// Heading
$_['heading_title']     = 'Įsigytų prekių ataskaita';

// Text
$_['text_all_status']   = 'Visos būsenos';

// Column
$_['column_date_start'] = 'Pradžia';
$_['column_date_end']   = 'Pabaiga';
$_['column_name']       = 'Prekė';
$_['column_model']      = 'Modelis';
$_['column_quantity']   = 'Kiekis';
$_['column_total']      = 'Viso';

// Entry
$_['entry_date_start']  = 'Pradžia:';
$_['entry_date_end']    = 'Pabaiga:';
$_['entry_status']      = 'Užsakymo būsena:';
?>