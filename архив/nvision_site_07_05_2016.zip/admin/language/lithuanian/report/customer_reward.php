<?php
// Heading
$_['heading_title']         = 'Apdovanojimo taškų ataskaita';

// Column
$_['column_customer']       = 'Klientas';
$_['column_email']          = 'El. paštas';
$_['column_customer_group'] = 'Klientų grupė';
$_['column_status']         = 'Būsena';
$_['column_points']         = 'Taškai';
$_['column_orders']         = 'Užsakymai, vnt.';
$_['column_total']          = 'Viso';
$_['column_action']         = 'Veiksmai';

// Entry
$_['entry_date_start']      = 'Pradžia:';
$_['entry_date_end']        = 'Pabaiga:';
?>