<?php

//
// developer.lt
//

// Heading
$_['heading_title']    = 'Kategorijos';

// Text
$_['text_module']      = 'Moduliai';
$_['text_success']     = 'Jūs sėkmingai modifikavote Kategorijos modulį!';
$_['text_content_top']    = 'Viršus';
$_['text_content_bottom'] = 'Apačia';
$_['text_column_left']    = 'Kairė';
$_['text_column_right']   = 'Dešinė';

// Entry
$_['entry_position']   = 'Pozicija:';
$_['entry_status']     = 'Būsena:';
$_['entry_layout']     = 'Išsidėstymas:';
$_['entry_sort_order'] = 'Rikiavimas:';
//$_['entry_count'] 	   = 'Skaičiuoti prekes:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti Kategorijos modulį!';
?>