<?php

//
// developer.lt
//

// Heading
$_['heading_title']       = 'Paskyra';

// Text
$_['text_module']         = 'Moduliai';
$_['text_success']        = 'Sėkmingai atnaujinote paskyros modulio duomenis!';
$_['text_content_top']    = 'Viršus';
$_['text_content_bottom'] = 'Apačia';
$_['text_column_left']    = 'Kairė';
$_['text_column_right']   = 'Dešinė';

// Entry
$_['entry_layout']        = 'Išsidėstymas:';
$_['entry_position']      = 'Pozicija:';
$_['entry_status']        = 'Būsena:';
$_['entry_sort_order']    = 'Rikiavimas:';

// Error
$_['error_permission']    = 'Neturite teisių paskyros modulio redagavimui!';
?>