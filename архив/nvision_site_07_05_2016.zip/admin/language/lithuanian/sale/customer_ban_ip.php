<?php

//
// developer.lt
//

// Heading
$_['heading_title']    = 'Blokuoti klientų IP';

// Text
$_['text_success']     = 'Sėkmingai išaugoti blokuotų IP pakeitimai!';

// Column
$_['column_ip']        = 'IP';
$_['column_customer']  = 'Klientai';
$_['column_action']    = 'Veiksmas';

// Entry
$_['entry_ip']         = 'IP adresas:';

// Error
$_['error_permission'] = 'Neturite teisių modifikuoti blokuotus IP!';
$_['error_ip']         = 'IP adreso ilgis turi būti nuo 1 iki 15 simbolių!';
?>