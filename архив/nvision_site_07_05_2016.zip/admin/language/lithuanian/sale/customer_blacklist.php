<?php
// Heading
$_['heading_title']    = 'Klientų IP adresų juodasis sąrašas';

// Text
$_['text_success']     = 'Sėkmingai atnaujinote IP juodąjį sąrašą!';

// Column
$_['column_ip']        = 'IP';
$_['column_customer']  = 'Klientai';
$_['column_action']    = 'Veiksmas';

// Entry
$_['entry_ip']         = 'IP:';

// Error
$_['error_permission'] = 'Neturite teisių IP juodojo sąrašo modifikavimui!';
$_['error_ip']         = 'IP adreso ilgis turi būti nuo 1 iki 15 simbolių!';
?>