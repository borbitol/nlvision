<?php
// Heading
$_['heading_title']    = 'Prekės būsena';

// Text
$_['text_success']     = 'Jūs sėkmingai modifikavote prekės būsenas!';

// Column
$_['column_name']      = 'Prekės būsenos pavadinimas';
$_['column_action']    = 'Veiksmas';

// Entry
$_['entry_name']       = 'Prekės būsenos pavadinimas:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti prekės būsenas!';
$_['error_name']       = 'Prekės būsenos pavadinimas turi būti nuo 3 iki 32 simbolių!';
$_['error_product']    = 'Prekės būsena negali būti pašalinta, nes ji priskirta %s prekėms!';
?>
