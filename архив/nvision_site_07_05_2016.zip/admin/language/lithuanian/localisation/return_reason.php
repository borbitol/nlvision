<?php
// Heading
$_['heading_title']    = 'Grąžinimo priežastys';

// Text
$_['text_success']     = 'Sėkmingai atnaujinote grąžinimo priežastis!';

// Column
$_['column_name']      = 'Grąžinimo priežasties pavadinimas';
$_['column_action']    = 'Veiksmas';

// Entry
$_['entry_name']       = 'Grąžinimo priežasties pavadinimas:';

// Error
$_['error_permission'] = 'Neturite pakankamai teisių šių duomenų keitimui!';
$_['error_name']       = 'Grąžinimo priežasties pavadinimo ilgis turi būti nuo 3 iki 32 simbolių!';
$_['error_return']     = 'Negalite pašalinti šios priežasties, nes ji yra priskirta grąžintoms prekėms (%s)!';
?>