<?php
// Heading
$_['heading_title']    = 'Grąžinimo veiksmai';

// Text
$_['text_success']     = 'Sėkmingai atnaujinote grąžinimo veiksmus!';

// Column
$_['column_name']      = 'Grąžinimo veiksmo pavadinimas';
$_['column_action']    = 'Veiksmas';

// Entry
$_['entry_name']       = 'Grąžinimo veiksmo pavadinimas:';

// Error
$_['error_permission'] = 'Neturite pakankamai teisių šių duomenų keitimui!';
$_['error_name']       = 'Grąžinimo veiksmo pavadinimo ilgis turi būti nuo 3 iki 32 simboliių!';
$_['error_return']     = 'Šis veiksmas negali būti pašalintas, nes yra priskirtas grąžintoms prekėms (%s)!';
?>