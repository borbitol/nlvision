<?php
// Heading
$_['heading_title']     = 'Доставка';

// Text
$_['text_install']      = 'Установить';
$_['text_uninstall']    = 'Удалить';

// Column
$_['column_name']       = 'Способ доставки';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Порядок сортировки';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'У Вас нет прав для управления доставкой!';
?>